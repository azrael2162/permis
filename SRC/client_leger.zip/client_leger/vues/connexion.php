<?php
require 'fonctionphp/connexion.php';
 ?>
<div class="container">
<br><br><br>
<h4>Connexion :</h4>
<div class="col">
  <br>
  <form class="" action="" method="post">
    <input type="email" class="form-control" name="mail" placeholder="Email"> <br>
    <input type="password" class="form-control" name="passwd" placeholder="Password"><br>
    <input type="submit" name="valider" value="Se connecter" class="btn btn-primary btn-lg btn-block">
    <?php Connexion(); ?>
  </form>
</div>
</div>
