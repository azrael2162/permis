<br><br><br><br>
<div class="container">
  <div class="row">
    <br><br><br>
    <div class="col-sm">
      <div class="col">
        <img src=""  class=" img-fluid d-block mx-auto" height="128px" width="128px" alt=""><br>
        <center><b> Passer le Code <br></b></center>
      </div>
      <br>
      <br>
    </div>
    <div class="col-sm">
      <img src="img/progress.png"  class="rounded-circle img-fluid d-block mx-auto" height="128px" width="128px" alt=""><br>
      <center><b><br>Passer le Code et le permis</b>
    </div>
    <br>
    </div>
</div>
